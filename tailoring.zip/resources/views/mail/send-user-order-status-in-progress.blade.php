<x-mail::message>
    **Dear Customer,**  

    Your order is now **in progress**. Our tailoring team is already working on it, and we’ll update you once it’s ready.  

    Thank you for choosing **{{ config('app.name') }}**! We appreciate your trust in us.  

    **Best regards,**  
    **{{ config('app.name') }}** ✂️  
</x-mail::message>
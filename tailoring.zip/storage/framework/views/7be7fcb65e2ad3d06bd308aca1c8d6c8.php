<div class="card col-4">
    <div class="card-header">
        <h3>Uniform Prices</h3>
    </div>
    <div class="card-body">
        <?php $__currentLoopData = $uniformPrices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uniformPrice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="mb-3">
                <h5><?php echo e($uniformPrice->name); ?></h5>
                <ul>
                <?php $__currentLoopData = $uniformPrice->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($item->name); ?>: <?php echo e($item->price); ?></li>
                    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH C:\Users\TourismoPH\Herd\mmrc_tailoring\resources\views/user/order/uniform_prices.blade.php ENDPATH**/ ?>
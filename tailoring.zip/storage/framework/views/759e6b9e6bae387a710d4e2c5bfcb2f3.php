<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Dashboard</h3>
                </div>
                <!-- /.card-header -->
                <div class="card-body">
                    <p>Welcome <?php echo e(auth()->user()->fullname); ?>.</p>
                </div>

                <div class="container-fluid">
                    <h4 class="text-danger fw-bold">Appointment Counts</h4>
                    <div class="row">
                        <div class="col-lg-3 col-6">
                            <!-- small box -->
                            <div class="small-box bg-secondary">
                                <div class="inner">
                                    <h3><?php echo e($pendingAppointments); ?></h3>

                                    <p>Pending Appointments</p>
                                </div>
                                <div class="icon">
                                    <i class="ion ion-bag"></i>
                                </div>
                                <a href="<?php echo e(route('admin.appointment.index', ['status' => 'pending'])); ?>"
                                    class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                            </div>
                        </div>
                        <!-- ./col -->
                        <div class="col-lg-3 col-6">
                            <!-- small box -->
                            <div class="small-box bg-info">
                                <div class="inner">
                                    <h3><?php echo e($inProgressAppointments); ?></h3>

                                    <p>In Progress Appointments</p>
                                </div>
                                <div class="icon">
                                    <i class="ion ion-stats-bars"></i>
                                </div>
                                <a href="<?php echo e(route('admin.appointment.index', ['status' => 'in-progress'])); ?>"
                                    class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                            </div>
                        </div>
                        <!-- ./col -->
                        <div class="col-lg-3 col-6">
                            <!-- small box -->
                            <div class="small-box bg-primary">
                                <div class="inner">
                                    <h3><?php echo e($doneAppointments); ?></h3>

                                    <p>Done Appointments</p>
                                </div>
                                <div class="icon">
                                    <i class="ion ion-person-add"></i>
                                </div>
                                <a href="<?php echo e(route('admin.appointment.index', ['status' => 'done'])); ?>"
                                    class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                            </div>
                        </div>
                        <!-- ./col -->
                        <div class="col-lg-3 col-6">
                            <!-- small box -->
                            <div class="small-box bg-success">
                                <div class="inner">
                                    <h3><?php echo e($completedAppointments); ?></h3>

                                    <p>Completed Appointments</p>
                                </div>
                                <div class="icon">
                                    <i class="ion ion-pie-graph"></i>
                                </div>
                                <a href="<?php echo e(route('admin.appointment.index', ['status' => 'completed'])); ?>"
                                    class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                            </div>
                        </div>
                        <!-- ./col -->
                    </div>

                    
                    <h4 class="text-danger fw-bold">Order Counts</h4>
                    <div class="row mb-4">
                        <div class="col-lg-3 col-6">
                            <!-- small box -->
                            <div class="small-box bg-secondary">
                                <div class="inner">
                                    <h3><?php echo e($pendingOrders); ?></h3>

                                    <p>Pending Orders</p>
                                </div>
                                <div class="icon">
                                    <i class="ion ion-bag"></i>
                                </div>
                                <a href="<?php echo e(route('admin.appointment.index', ['status' => 'pending'])); ?>"
                                    class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                            </div>
                        </div>
                        <!-- ./col -->
                        <div class="col-lg-3 col-6">
                            <!-- small box -->
                            <div class="small-box bg-info">
                                <div class="inner">
                                    <h3><?php echo e($inProgressOrders); ?></h3>

                                    <p>In Progress Orders</p>
                                </div>
                                <div class="icon">
                                    <i class="ion ion-stats-bars"></i>
                                </div>
                                <a href="<?php echo e(route('admin.appointment.index', ['status' => 'in-progress'])); ?>"
                                    class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                            </div>
                        </div>
                        <!-- ./col -->
                        <div class="col-lg-3 col-6">
                            <!-- small box -->
                            <div class="small-box bg-primary">
                                <div class="inner">
                                    <h3><?php echo e($doneOrders); ?></h3>

                                    <p>Done Orders</p>
                                </div>
                                <div class="icon">
                                    <i class="ion ion-person-add"></i>
                                </div>
                                <a href="<?php echo e(route('admin.appointment.index', ['status' => 'done'])); ?>"
                                    class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                            </div>
                        </div>
                        <!-- ./col -->
                        <div class="col-lg-3 col-6">
                            <!-- small box -->
                            <div class="small-box bg-success">
                                <div class="inner">
                                    <h3><?php echo e($completedOrders); ?></h3>

                                    <p>Completed Orders</p>
                                </div>
                                <div class="icon">
                                    <i class="ion ion-pie-graph"></i>
                                </div>
                                <a href="<?php echo e(route('admin.appointment.index', ['status' => 'completed'])); ?>"
                                    class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                            </div>
                        </div>
                        <!-- ./col -->
                    </div>

                    
                    <div class="card mb-4">
                        <div class="card-header border-transparent">
                            <h3 class="card-title text-danger fw-bold">5 Latest Appointments</h3>

                            <div class="card-tools">
                                <a href="<?php echo e(route('admin.appointment.index', [
                        'status' => 'pending'])); ?>" class="btn btn-tool" data-card-widget="collapse">
                                   View more
                                </a>

                            </div>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table m-0">
                                    <thead>
                                        <tr>
                                            <th>Full Name</th>
                                            <th>Emal</th>
                                            <th>Appointment Date</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                               <td><?php echo e($appointment->user->fullname); ?></td>
                                                <td><?php echo e($appointment->user->email); ?></td>
                                                <td><?php echo e($appointment->date); ?></td>
                                                <td>
                                                    <?php if($appointment->status === 'pending'): ?>
                                                        <span class="badge rounded-pill text-bg-secondary">Pending</span>
                                                    <?php elseif($appointment->status === 'in-progress'): ?>
                                                        <span class="badge rounded-pill text-bg-warning">
                                                            In Progress - <span
                                                                class="<?php echo e($appointment->topMeasurement || $appointment->bottomMeasurement ? 'text-success' : 'text-danger'); ?>">(<?php echo e($appointment->topMeasurement || $appointment->bottomMeasurement ? 'measured' : 'pending measurement'); ?>)</span>
                                                        </span>
                                                    <?php elseif($appointment->status === 'done'): ?>
                                                        <span class="badge rounded-pill text-bg-info">Done</span>
                                                    <?php elseif($appointment->status === 'completed'): ?>
                                                        <span class="badge rounded-pill text-bg-success">Completed</span>
                                                    <?php else: ?>
                                                        <span class="badge rounded-pill text-bg-danger">No Show</span>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tr>
                                                <td>No Data</td>
                                            </tr>
                                        <?php endif; ?>

                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>

                        <!-- /.card-footer -->
                    </div>
                    
                    <div class="card mb-4">
                        <div class="card-header border-transparent">
                            <h3 class="card-title text-danger fw-bold">5 Latest Orders</h3>

                            <div class="card-tools">
                                <a href="<?php echo e(route('admin.order.index', [
                        'status' => 'pending'])); ?>" class="btn btn-tool" data-card-widget="collapse">
                                   View more
                                </a>

                            </div>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table m-0">
                                    <thead>
                                        <tr>
                                            <th>User</th>
                                            <th>Order Type</th>
                                            <th>Payment Status</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($order->user->fullname); ?></td>
                                                <td><?php echo e($order->order_type); ?></td>
                                                <td><?php echo e($order->payment_status); ?></td>
                                                <td>
                                                    <?php if($order->status === 'pending'): ?>
                                                        <span class="badge rounded-pill text-bg-secondary">Pending</span>
                                                    <?php elseif($order->status === 'in-progress'): ?>
                                                        <span class="badge rounded-pill text-bg-info">In Progress</span>
                                                    <?php elseif($order->status === 'done'): ?>
                                                        <span class="badge rounded-pill text-bg-primary">Done</span>
                                                    <?php else: ?>
                                                        <span class="badge rounded-pill text-bg-success">Completed</span>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>

                        <!-- /.card-footer -->
                    </div>
                </div>
                <!-- /.card-body -->
            </div>
            <!-- /.card -->
        </div>
        <!-- /.col -->
    </div>
    <!-- /.row -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TourismoPH\Herd\mmrc_tailoring\resources\views/admin/index.blade.php ENDPATH**/ ?>
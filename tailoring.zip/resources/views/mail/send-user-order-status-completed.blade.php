<x-mail::message>
    **Dear Customer,**  

    Your order is now **complete**!  

    Thank you for choosing **{{ config('app.name') }}**. We truly appreciate your trust in our tailor shop.  

    **Best regards,**  
    **{{ config('app.name') }}** ✂️  
</x-mail::message>

<?php $__env->startSection('title', 'Settings'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-6 mx-auto">
       
        <?php $__sessionArgs = ['success'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('success')); ?>

            </div>
        <?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>
        <div class="card">
            <div class="card-header">
                <div class="card-title">Appointment Max Limit</div>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('admin.settings.appointment-limit.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['label' => 'Appointment Limit (Per Day)','name' => 'limit','value' => ''.e($limit).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Appointment Limit (Per Day)','name' => 'limit','value' => ''.e($limit).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
                    <button type="submit" class="btn btn-primary w-100 mt-2">Save</button>
                </form>
            </div>
        </div>
    </div>
    <!-- /.col -->
</div>
<!-- /.row -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TourismoPH\Herd\mmrc_tailoring\resources\views/admin/settings/appointment_limit.blade.php ENDPATH**/ ?>
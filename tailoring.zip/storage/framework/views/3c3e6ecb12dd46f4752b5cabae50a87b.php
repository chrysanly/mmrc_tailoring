<footer id="footer">
    <div class="container px-4 py-5">

        <div class="d-flex justify-content-around align-items-center">
            <div>
                <h5>Operating Hours (<?php echo e($scheduleTitle); ?>)</h5>
                <?php $__currentLoopData = $storeSchedule; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($schedule); ?> <br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
            <div>
                <h5>Contact us</h5>
                <p>Subybyc Z.C</p>
                <a href="#">merzsevilla1997@gmail.com</a>
                <p>09123456789</p>
                <a href="#">Facebook Link</a>
            </div>
        </div>

    </div>
</footer>
<?php /**PATH C:\Users\TourismoPH\Herd\mmrc_tailoring\resources\views/layouts/footer.blade.php ENDPATH**/ ?>
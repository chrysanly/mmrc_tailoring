<?php $__env->startSection('title', 'Settings'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <div class="card-title">Payment Options</div>
            </div>
            <div class="card-body">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Account Number</th>
                            <th>Account Name</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>
                <div id="pagination"></div>
                
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="alert alert-success d-none" role="alert">
            <span id="alert-message"><?php echo e(session('success')); ?></span>
        </div>
        <div class="card">
            <div class="card-header">
                <div class="card-title">Create Payment Option</div>
            </div>
            <div class="card-body">
                <form id="payment-option-form" action="<?php echo e(route('admin.settings.payment-option.store')); ?>">
                    <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['label' => 'Name','name' => 'name']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Name','name' => 'name']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['label' => 'Account Number','name' => 'account_number']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Account Number','name' => 'account_number']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['label' => 'Account Name','name' => 'account_name']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Account Name','name' => 'account_name']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
                    <div class="d-flex gap-2">
                        <a class="btn btn-secondary w-100 mt-2" id="clear-button">Cancel</a>
                        <button type="button" id="submitButton" class="btn btn-primary w-100 mt-2">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('assets/admin/js/payment_option.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TourismoPH\Herd\mmrc_tailoring\resources\views/admin/settings/payment_option.blade.php ENDPATH**/ ?>
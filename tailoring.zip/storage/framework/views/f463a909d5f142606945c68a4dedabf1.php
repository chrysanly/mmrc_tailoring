<div class="card">
    <div class="card-header">
        <h5>Additional Items</h5>
    </div>
    <div class="card-body">
        <div class="d-flex justify-content-evenly">
            <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'additional_threads','type' => 'number','label' => 'Threads']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'additional_threads','type' => 'number','label' => 'Threads']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'additional_zipper','type' => 'number','label' => 'Zipper']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'additional_zipper','type' => 'number','label' => 'Zipper']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'additional_school_seal','type' => 'number','label' => 'School Seal']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'additional_school_seal','type' => 'number','label' => 'School Seal']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
        </div>
        <div class="d-flex justify-content-evenly">
            <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'additional_buttons','type' => 'number','label' => 'Buttons']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'additional_buttons','type' => 'number','label' => 'Buttons']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'additional_hook_eye','type' => 'number','label' => 'Hook and Eye']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'additional_hook_eye','type' => 'number','label' => 'Hook and Eye']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'additional_tela','type' => 'number','label' => 'Tela']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'additional_tela','type' => 'number','label' => 'Tela']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\TourismoPH\Herd\mmrc_tailoring\resources\views/user/order/additional-items.blade.php ENDPATH**/ ?>
<?php echo $__env->make('layouts.admin.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<body class="layout-fixed sidebar-expand-lg sidebar-mini bg-body-tertiary">
    <!--begin::App Wrapper-->
    <div class="app-wrapper">
        <!--begin::Header-->
        <nav class="app-header navbar navbar-expand bg-body">
            <!--begin::Container-->
            <div class="container-fluid">
                <!--begin::Start Navbar Links-->
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" data-lte-toggle="sidebar" href="#" role="button">
                            <i class="bi bi-list"></i>
                        </a>
                    </li>
                </ul>
                <!--end::Start Navbar Links-->
                <!--begin::End Navbar Links-->
                <ul class="navbar-nav ms-auto">
                    <!--begin::User Menu Dropdown-->
                    <li class="nav-item dropdown user-menu">
                        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                            <span class="d-none d-md-inline"><?php echo e(auth()->user()->fullname); ?></span>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-md dropdown-menu-end w-50">
                            <form action="<?php echo e(route('logout')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-default btn-flat">Sign out</button>
                            </form>
                            <!--end::Menu Footer-->
                        </ul>
                    </li>
                    <!--end::User Menu Dropdown-->
                </ul>
                <!--end::End Navbar Links-->
            </div>
            <!--end::Container-->
        </nav>
        <!--end::Header-->
        <!--begin::Sidebar-->
        <aside class="app-sidebar bg-body-secondary shadow" data-bs-theme="dark">
            <!--begin::Sidebar Brand-->
            <div class="sidebar-brand">
                <!--begin::Brand Link-->
                <a href="/admin/dashboard" class="brand-link">
                    <!--begin::Brand Image-->
                    <span class="brand-image opacity-75 shadow fw-bold">MMRC</span>
                    <!--end::Brand Image-->
                    <!--begin::Brand Text-->
                    <span class="brand-text fw-light"> Tailoring</span>
                    <!--end::Brand Text-->
                </a>
                <!--end::Brand Link-->
            </div>
            <!--end::Sidebar Brand-->
            <!--begin::Sidebar Wrapper-->
            <div class="sidebar-wrapper">
                <nav class="mt-2">
                    <!--begin::Sidebar Menu-->
                    <ul class="nav sidebar-menu flex-column" data-lte-toggle="treeview" role="menu"
                        data-accordion="false">

                        

                        <?php if (isset($component)) { $__componentOriginalc83a98630b93a7364af34bfe74758377 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc83a98630b93a7364af34bfe74758377 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.list-link','data' => ['link' => ''.e(route('admin.dashboard')).'','active' => ''.e(request()->routeIs('admin.dashboard')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.list-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['link' => ''.e(route('admin.dashboard')).'','active' => ''.e(request()->routeIs('admin.dashboard')).'']); ?>
                             <?php $__env->slot('title', null, []); ?> Dashboard <?php $__env->endSlot(); ?>
                             <?php $__env->slot('icon', null, []); ?> <i class="nav-icon bi bi-speedometer"></i> <?php $__env->endSlot(); ?>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc83a98630b93a7364af34bfe74758377)): ?>
<?php $attributes = $__attributesOriginalc83a98630b93a7364af34bfe74758377; ?>
<?php unset($__attributesOriginalc83a98630b93a7364af34bfe74758377); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc83a98630b93a7364af34bfe74758377)): ?>
<?php $component = $__componentOriginalc83a98630b93a7364af34bfe74758377; ?>
<?php unset($__componentOriginalc83a98630b93a7364af34bfe74758377); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginalc83a98630b93a7364af34bfe74758377 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc83a98630b93a7364af34bfe74758377 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.list-link','data' => ['link' => ''.e(route('admin.appointment.index', ['status' => 'all'])).'','active' => ''.e(request()->routeIs('admin.appointment.index')).'','hasCount' => 'true','count' => appointmentPendingCount()]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.list-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['link' => ''.e(route('admin.appointment.index', ['status' => 'all'])).'','active' => ''.e(request()->routeIs('admin.appointment.index')).'','hasCount' => 'true','count' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(appointmentPendingCount())]); ?>
                             <?php $__env->slot('title', null, []); ?> Appointments <?php $__env->endSlot(); ?>
                             <?php $__env->slot('icon', null, []); ?> <i class="nav-icon bi bi-calendar-check"></i> <?php $__env->endSlot(); ?>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc83a98630b93a7364af34bfe74758377)): ?>
<?php $attributes = $__attributesOriginalc83a98630b93a7364af34bfe74758377; ?>
<?php unset($__attributesOriginalc83a98630b93a7364af34bfe74758377); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc83a98630b93a7364af34bfe74758377)): ?>
<?php $component = $__componentOriginalc83a98630b93a7364af34bfe74758377; ?>
<?php unset($__componentOriginalc83a98630b93a7364af34bfe74758377); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginalc83a98630b93a7364af34bfe74758377 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc83a98630b93a7364af34bfe74758377 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.list-link','data' => ['link' => ''.e(route('admin.order.index', [
                        'status' => 'pending'])).'','active' => ''.e(request()->routeIs('admin.order.index')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.list-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['link' => ''.e(route('admin.order.index', [
                        'status' => 'pending'])).'','active' => ''.e(request()->routeIs('admin.order.index')).'']); ?>
                             <?php $__env->slot('title', null, []); ?> Orders <?php $__env->endSlot(); ?>
                             <?php $__env->slot('icon', null, []); ?> <i class="nav-icon bi bi-bag-check"></i> <?php $__env->endSlot(); ?>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc83a98630b93a7364af34bfe74758377)): ?>
<?php $attributes = $__attributesOriginalc83a98630b93a7364af34bfe74758377; ?>
<?php unset($__attributesOriginalc83a98630b93a7364af34bfe74758377); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc83a98630b93a7364af34bfe74758377)): ?>
<?php $component = $__componentOriginalc83a98630b93a7364af34bfe74758377; ?>
<?php unset($__componentOriginalc83a98630b93a7364af34bfe74758377); ?>
<?php endif; ?>
                       <?php if(auth()->user()->role === 'superadmin'): ?>
                            <?php if (isset($component)) { $__componentOriginalc83a98630b93a7364af34bfe74758377 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc83a98630b93a7364af34bfe74758377 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.list-link','data' => ['link' => ''.e(route('admin.uniform-price.index')).'','active' => ''.e(request()->routeIs('admin.uniform-price.index')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.list-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['link' => ''.e(route('admin.uniform-price.index')).'','active' => ''.e(request()->routeIs('admin.uniform-price.index')).'']); ?>
                             <?php $__env->slot('title', null, []); ?> Uniform Prices <?php $__env->endSlot(); ?>
                             <?php $__env->slot('icon', null, []); ?> <i class="nav-icon bi bi-tags"></i> <?php $__env->endSlot(); ?>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc83a98630b93a7364af34bfe74758377)): ?>
<?php $attributes = $__attributesOriginalc83a98630b93a7364af34bfe74758377; ?>
<?php unset($__attributesOriginalc83a98630b93a7364af34bfe74758377); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc83a98630b93a7364af34bfe74758377)): ?>
<?php $component = $__componentOriginalc83a98630b93a7364af34bfe74758377; ?>
<?php unset($__componentOriginalc83a98630b93a7364af34bfe74758377); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginalc83a98630b93a7364af34bfe74758377 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc83a98630b93a7364af34bfe74758377 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.list-link','data' => ['link' => ''.e(route('admin.admin-users.index')).'','active' => ''.e(request()->routeIs('admin.admin-users.index')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.list-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['link' => ''.e(route('admin.admin-users.index')).'','active' => ''.e(request()->routeIs('admin.admin-users.index')).'']); ?>
                             <?php $__env->slot('title', null, []); ?> Admin Users <?php $__env->endSlot(); ?>
                             <?php $__env->slot('icon', null, []); ?> <i class="nav-icon bi-person-gear"></i> <?php $__env->endSlot(); ?>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc83a98630b93a7364af34bfe74758377)): ?>
<?php $attributes = $__attributesOriginalc83a98630b93a7364af34bfe74758377; ?>
<?php unset($__attributesOriginalc83a98630b93a7364af34bfe74758377); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc83a98630b93a7364af34bfe74758377)): ?>
<?php $component = $__componentOriginalc83a98630b93a7364af34bfe74758377; ?>
<?php unset($__componentOriginalc83a98630b93a7364af34bfe74758377); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginalfe57278e967875e05558116cafe941a1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfe57278e967875e05558116cafe941a1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.dropdown-list','data' => ['active' => ''.e(request()->routeIs('admin.settings.*')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.dropdown-list'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['active' => ''.e(request()->routeIs('admin.settings.*')).'']); ?>
                             <?php $__env->slot('title', null, []); ?> Settings <?php $__env->endSlot(); ?>
                             <?php $__env->slot('icon', null, []); ?> <i class="nav-icon bi bi-gear"></i> <?php $__env->endSlot(); ?>
                            <?php if (isset($component)) { $__componentOriginalc83a98630b93a7364af34bfe74758377 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc83a98630b93a7364af34bfe74758377 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.list-link','data' => ['link' => ''.e(route('admin.settings.appointment-limit')).'','active' => ''.e(request()->routeIs('admin.settings.appointment-limit')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.list-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['link' => ''.e(route('admin.settings.appointment-limit')).'','active' => ''.e(request()->routeIs('admin.settings.appointment-limit')).'']); ?>
                                 <?php $__env->slot('title', null, []); ?> Appointment Limit <?php $__env->endSlot(); ?>
                                 <?php $__env->slot('icon', null, []); ?> <i class="nav-icon bi bi-calendar2-check"></i> <?php $__env->endSlot(); ?>
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc83a98630b93a7364af34bfe74758377)): ?>
<?php $attributes = $__attributesOriginalc83a98630b93a7364af34bfe74758377; ?>
<?php unset($__attributesOriginalc83a98630b93a7364af34bfe74758377); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc83a98630b93a7364af34bfe74758377)): ?>
<?php $component = $__componentOriginalc83a98630b93a7364af34bfe74758377; ?>
<?php unset($__componentOriginalc83a98630b93a7364af34bfe74758377); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginalc83a98630b93a7364af34bfe74758377 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc83a98630b93a7364af34bfe74758377 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.list-link','data' => ['link' => ''.e(route('admin.settings.payment-option')).'','active' => ''.e(request()->routeIs('admin.settings.payment-option')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.list-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['link' => ''.e(route('admin.settings.payment-option')).'','active' => ''.e(request()->routeIs('admin.settings.payment-option')).'']); ?>
                                 <?php $__env->slot('title', null, []); ?> Payment Options <?php $__env->endSlot(); ?>
                                 <?php $__env->slot('icon', null, []); ?> <i class="nav-icon bi bi-credit-card"></i> <?php $__env->endSlot(); ?>
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc83a98630b93a7364af34bfe74758377)): ?>
<?php $attributes = $__attributesOriginalc83a98630b93a7364af34bfe74758377; ?>
<?php unset($__attributesOriginalc83a98630b93a7364af34bfe74758377); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc83a98630b93a7364af34bfe74758377)): ?>
<?php $component = $__componentOriginalc83a98630b93a7364af34bfe74758377; ?>
<?php unset($__componentOriginalc83a98630b93a7364af34bfe74758377); ?>
<?php endif; ?>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfe57278e967875e05558116cafe941a1)): ?>
<?php $attributes = $__attributesOriginalfe57278e967875e05558116cafe941a1; ?>
<?php unset($__attributesOriginalfe57278e967875e05558116cafe941a1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfe57278e967875e05558116cafe941a1)): ?>
<?php $component = $__componentOriginalfe57278e967875e05558116cafe941a1; ?>
<?php unset($__componentOriginalfe57278e967875e05558116cafe941a1); ?>
<?php endif; ?>
                       <?php endif; ?>
                    </ul>
                    <!--end::Sidebar Menu-->
                </nav>
            </div>
            <!--end::Sidebar Wrapper-->
        </aside>
        <!--end::Sidebar-->
        <!--begin::App Main-->
        <main class="app-main">
            <!--begin::App Content Header-->
            <div class="app-content-header">
                <!--begin::Container-->
                <div class="container-fluid">
                    <!--begin::Row-->
                    <div class="row">

                    </div>
                    <!--end::Row-->
                </div>
                <!--end::Container-->
            </div>
            <!--end::App Content Header-->
            <!--begin::App Content-->
            <div class="app-content">
                <!--begin::Container-->
                <div class="container-fluid">
                    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
                <!--end::Container-->
            </div>
            <!--end::App Content-->
        </main>
        <!--end::App Main-->
    </div>
    <!--end::App Wrapper-->
<?php echo $__env->make('layouts.admin.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TourismoPH\Herd\mmrc_tailoring\resources\views/layouts/admin/app.blade.php ENDPATH**/ ?>
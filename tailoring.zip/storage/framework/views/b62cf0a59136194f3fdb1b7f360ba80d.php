<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['title' => '', 'icon' => '', 'link' => '#', 'active' => false, 'hasCount' => false, 'count' => 0]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['title' => '', 'icon' => '', 'link' => '#', 'active' => false, 'hasCount' => false, 'count' => 0]); ?>
<?php foreach (array_filter((['title' => '', 'icon' => '', 'link' => '#', 'active' => false, 'hasCount' => false, 'count' => 0]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<li class="nav-item">
    <a href="<?php echo e($link); ?>" class="nav-link <?php echo e($active ? 'active' : ''); ?>">
        <?php echo e($icon); ?>

       
       <?php if($hasCount): ?>
        <div class="d-flex gap-2">
            <p><?php echo e($title); ?></p>
            <span class="badge text-bg-danger text-center"><?php echo e($count); ?></span>
        </div>
            <?php else: ?>
             <p><?php echo e($title); ?></p>
       <?php endif; ?>
    </a>
</li><?php /**PATH C:\Users\TourismoPH\Herd\mmrc_tailoring\resources\views/components/admin/list-link.blade.php ENDPATH**/ ?>
<x-mail::message>
    Dear customer,

    Great news! Your order is now done and ready for pickup. Please settle the remaining balance to claim your order.

    If you have any questions, feel free to reach out. See you soon!

    Best,
    {{ config('app.name') }}✂️
</x-mail::message>

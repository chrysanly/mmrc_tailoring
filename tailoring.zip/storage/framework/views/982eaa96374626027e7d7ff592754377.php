<?php $__env->startSection('title', 'Appointments'); ?>

<?php $__env->startSection('content'); ?>

    <?php
        $tabs = [
            [
                'id' => 'all',
                'name' => 'All',
                'route' => route('admin.appointment.index', [
                    'status' => 'all',
                ]),
            ],
            [
                'id' => 'pending',
                'name' => 'Pending',
                'route' => route('admin.appointment.index', [
                    'status' => 'pending',
                ]),
            ],
            [
                'id' => 'in-progress',
                'name' => 'In Progress',
                'route' => route('admin.appointment.index', [
                    'status' => 'in-progress',
                ]),
            ],
            [
                'id' => 'done',
                'name' => 'Done',
                'route' => route('admin.appointment.index', [
                    'status' => 'done',
                ]),
            ],
            [
                'id' => 'completed',
                'name' => 'Completed',
                'route' => route('admin.appointment.index', [
                    'status' => 'completed',
                ]),
            ],
            [
                'id' => 'no-show',
                'name' => 'No Show',
                'route' => route('admin.appointment.index', [
                    'status' => 'no-show',
                ]),
            ],
            [
                'id' => 'cancelled',
                'name' => 'Cancelled',
                'route' => route('admin.appointment.index', [
                    'status' => 'cancelled',
                ]),
            ],
        ];
    ?>

    <ul class="nav nav-tabs" id="myTab" role="tablist">
        <?php $__currentLoopData = $tabs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="nav-item" role="presentation">
                <a href="<?php echo e($item['route']); ?>" class="nav-link <?php echo e(request('status') === $item['id'] ? 'active' : ''); ?>"
                    id="<?php echo e($item['id']); ?>-tab" type="button" role="tab" aria-controls="<?php echo e($item['id']); ?>-tab-pane"
                    aria-selected="<?php echo e($item['id'] === 'pending' ? 'true' : 'false'); ?>"><?php echo e($item['name']); ?></a>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <div class="tab-content" id="myTabContent">
        <?php $__currentLoopData = $tabs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="tab-pane fade <?php echo e($item['id'] === request('status') ? 'show active' : ''); ?>"
                id="<?php echo e($item['id']); ?>-tab-pane" role="tabpanel" aria-labelledby="<?php echo e($item['id']); ?>-tab" tabindex="0">
                <div class="row mt-4">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Appointments</h3>
                            </div>

                            <div class="card-body">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th width="5">#</th>
                                            <th>User Name</th>
                                            <th>User Email</th>
                                            <th>Appointment Date</th>
                                            <th>Status</th>
                                            <?php if(request('status') === 'cancelled' || request('status') === 'all'): ?>
                                                <th>Remarks</th>
                                            <?php endif; ?>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td width="5"><?php echo e($appointment->id); ?></td>
                                                <td><?php echo e($appointment->user->fullname); ?></td>
                                                <td><?php echo e($appointment->user->email); ?></td>
                                                <td><?php echo e($appointment->date); ?></td>
                                               
                                                <td class="text-center">
                                                    <?php if($appointment->status === 'pending'): ?>
                                                        <span class="badge rounded-pill text-bg-secondary">Pending</span>
                                                    <?php elseif($appointment->status === 'in-progress'): ?>
                                                        <span class="badge rounded-pill text-bg-warning">
                                                            In Progress - <span
                                                                class="<?php echo e($appointment->topMeasurement || $appointment->bottomMeasurement ? 'text-success' : 'text-danger'); ?>">(<?php echo e($appointment->topMeasurement || $appointment->bottomMeasurement ? 'measured' : 'pending measurement'); ?>)</span>
                                                        </span>
                                                    <?php elseif($appointment->status === 'done'): ?>
                                                        <span class="badge rounded-pill text-bg-info">Done</span>
                                                    <?php elseif($appointment->status === 'completed'): ?>
                                                        <span class="badge rounded-pill text-bg-success">Completed</span>
                                                    <?php elseif($appointment->status === 'cancelled'): ?>
                                                        <span class="badge rounded-pill text-bg-danger">Cancelled</span>
                                                    <?php else: ?>
                                                        <span class="badge rounded-pill text-bg-danger">No Show</span>
                                                    <?php endif; ?>
                                                </td>

                                                 <?php if(request('status') === 'cancelled' || request('status') === 'all'): ?>
                                                <td><?php echo e($appointment->cancelled_reason ?? 'N/A'); ?></td>
                                            <?php endif; ?>

                                                <td>
                                                        <div class="dropdown">
                                                        <button class="btn btn-danger btn-sm dropdown-toggle" type="button"
                                                            data-bs-toggle="dropdown" aria-expanded="false" <?php echo e($appointment->status === 'no-show' || $appointment->status === 'cancelled' ? 'disabled' : ''); ?>>
                                                        </button>
                                                        <ul class="dropdown-menu">
                                                            <?php if($appointment->status === 'pending'): ?>
                                                                <li>
                                                                    <?php if (isset($component)) { $__componentOriginal5b00abe61963e2b73bd55171e0ab467d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5b00abe61963e2b73bd55171e0ab467d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.appointment-update-status','data' => ['id' => $appointment->id,'status' => 'in-progress','button' => 'Move to In Progress']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.appointment-update-status'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($appointment->id),'status' => 'in-progress','button' => 'Move to In Progress']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5b00abe61963e2b73bd55171e0ab467d)): ?>
<?php $attributes = $__attributesOriginal5b00abe61963e2b73bd55171e0ab467d; ?>
<?php unset($__attributesOriginal5b00abe61963e2b73bd55171e0ab467d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5b00abe61963e2b73bd55171e0ab467d)): ?>
<?php $component = $__componentOriginal5b00abe61963e2b73bd55171e0ab467d; ?>
<?php unset($__componentOriginal5b00abe61963e2b73bd55171e0ab467d); ?>
<?php endif; ?>
                                                                        <?php if (isset($component)) { $__componentOriginal5b00abe61963e2b73bd55171e0ab467d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5b00abe61963e2b73bd55171e0ab467d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.appointment-update-status','data' => ['id' => $appointment->id,'status' => 'no-show','button' => 'Move to No Show']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.appointment-update-status'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($appointment->id),'status' => 'no-show','button' => 'Move to No Show']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5b00abe61963e2b73bd55171e0ab467d)): ?>
<?php $attributes = $__attributesOriginal5b00abe61963e2b73bd55171e0ab467d; ?>
<?php unset($__attributesOriginal5b00abe61963e2b73bd55171e0ab467d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5b00abe61963e2b73bd55171e0ab467d)): ?>
<?php $component = $__componentOriginal5b00abe61963e2b73bd55171e0ab467d; ?>
<?php unset($__componentOriginal5b00abe61963e2b73bd55171e0ab467d); ?>
<?php endif; ?>
                                                                        <?php if (isset($component)) { $__componentOriginalc88e0ba996987ee6b8f0e68557f45854 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc88e0ba996987ee6b8f0e68557f45854 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.modal-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.modal-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> 
                                                                            testing modal
                                                                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc88e0ba996987ee6b8f0e68557f45854)): ?>
<?php $attributes = $__attributesOriginalc88e0ba996987ee6b8f0e68557f45854; ?>
<?php unset($__attributesOriginalc88e0ba996987ee6b8f0e68557f45854); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc88e0ba996987ee6b8f0e68557f45854)): ?>
<?php $component = $__componentOriginalc88e0ba996987ee6b8f0e68557f45854; ?>
<?php unset($__componentOriginalc88e0ba996987ee6b8f0e68557f45854); ?>
<?php endif; ?>
                                                                </li>
                                                            <?php endif; ?>
                                                            <?php if($appointment->topMeasurement || $appointment->bottomMeasurement): ?>
                                                                <?php if($appointment->status === 'in-progress'): ?>
                                                                    <li>
                                                                        <?php if (isset($component)) { $__componentOriginal5b00abe61963e2b73bd55171e0ab467d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5b00abe61963e2b73bd55171e0ab467d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.appointment-update-status','data' => ['id' => $appointment->id,'status' => 'done','button' => 'Move to Done']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.appointment-update-status'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($appointment->id),'status' => 'done','button' => 'Move to Done']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5b00abe61963e2b73bd55171e0ab467d)): ?>
<?php $attributes = $__attributesOriginal5b00abe61963e2b73bd55171e0ab467d; ?>
<?php unset($__attributesOriginal5b00abe61963e2b73bd55171e0ab467d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5b00abe61963e2b73bd55171e0ab467d)): ?>
<?php $component = $__componentOriginal5b00abe61963e2b73bd55171e0ab467d; ?>
<?php unset($__componentOriginal5b00abe61963e2b73bd55171e0ab467d); ?>
<?php endif; ?>
                                                                    </li>
                                                                <?php endif; ?>
                                                                <?php if($appointment->status === 'done'): ?>
                                                                    <?php if (isset($component)) { $__componentOriginal5b00abe61963e2b73bd55171e0ab467d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5b00abe61963e2b73bd55171e0ab467d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.appointment-update-status','data' => ['id' => $appointment->id,'status' => 'completed','button' => 'Move to Complete']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.appointment-update-status'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($appointment->id),'status' => 'completed','button' => 'Move to Complete']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5b00abe61963e2b73bd55171e0ab467d)): ?>
<?php $attributes = $__attributesOriginal5b00abe61963e2b73bd55171e0ab467d; ?>
<?php unset($__attributesOriginal5b00abe61963e2b73bd55171e0ab467d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5b00abe61963e2b73bd55171e0ab467d)): ?>
<?php $component = $__componentOriginal5b00abe61963e2b73bd55171e0ab467d; ?>
<?php unset($__componentOriginal5b00abe61963e2b73bd55171e0ab467d); ?>
<?php endif; ?>
                                                                    </li>
                                                                <?php endif; ?>

                                                                <?php if($appointment->status !== 'completed' && $appointment->status !== 'no-show'): ?>
                                                                    <li>
                                                                        <hr class="dropdown-divider">
                                                                    </li>
                                                                <?php endif; ?>
                                                                <li><a class="dropdown-item"
                                                                        href="<?php echo e(route('admin.appointment.view-measurement', $appointment->id)); ?>"
                                                                        target="_blank">View
                                                                        Measurement</a></li>
                                                            <?php endif; ?>
                                                            <?php if($appointment->status === 'in-progress' && !$appointment->topMeasurement && !$appointment->bottomMeasurement): ?>
                                                                <li>
                                                                    <a href="<?php echo e(route('admin.appointment.get-measurement', $appointment->id)); ?>"
                                                                        class="dropdown-item">Get
                                                                        Measurement</a>
                                                                </li>
                                                            <?php endif; ?>
                                                        </ul>
                                                    </div>

                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <div class="mt-4">
                                    <?php echo e($appointments->links()); ?>

                                </div>
                            </div>
                        </div>
                        <!-- /.card -->
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        function openModal(id) {
            var modal = new bootstrap.Modal(document.getElementById(id));
            modal.show();
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TourismoPH\Herd\mmrc_tailoring\resources\views/admin/appointment/index.blade.php ENDPATH**/ ?>
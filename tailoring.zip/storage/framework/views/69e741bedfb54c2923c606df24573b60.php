<?php $__env->startPush('scripts'); ?>
    <script>
        uniformTop.addEventListener('change', function() {
            hiddenTop.value = this.value;
        })

        uniformBottom.addEventListener('change', function() {
            hiddenBottom.value = this.value;
        })
    </script>
<?php $__env->stopPush(); ?>

<div class="card-header">
    <h5>Choose File</h5>
</div>
<div class="card-body">
    <div class="row mb-4">
        <?php if (isset($component)) { $__componentOriginald66f0cbab223ac1c229ab0c4874ff3f9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald66f0cbab223ac1c229ab0c4874ff3f9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user.select','data' => ['name' => 'file_school','title' => 'Select School','col' => 'col-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('user.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'file_school','title' => 'Select School','col' => 'col-4']); ?>
            <option value="WMSU" <?php echo e(old('file_school') === 'WMSU' ? 'selected' : ''); ?>>WMSU
            </option>
            <option value="ZPPSU" <?php echo e(old('file_school') === 'ZPPSU' ? 'selected' : ''); ?>>ZPPSU
            </option>
            <option value="SOUTHERN" <?php echo e(old('file_school') === 'SOUTHERN' ? 'selected' : ''); ?>>
                SOUTHERN</option>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald66f0cbab223ac1c229ab0c4874ff3f9)): ?>
<?php $attributes = $__attributesOriginald66f0cbab223ac1c229ab0c4874ff3f9; ?>
<?php unset($__attributesOriginald66f0cbab223ac1c229ab0c4874ff3f9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald66f0cbab223ac1c229ab0c4874ff3f9)): ?>
<?php $component = $__componentOriginald66f0cbab223ac1c229ab0c4874ff3f9; ?>
<?php unset($__componentOriginald66f0cbab223ac1c229ab0c4874ff3f9); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginald66f0cbab223ac1c229ab0c4874ff3f9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald66f0cbab223ac1c229ab0c4874ff3f9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user.select','data' => ['name' => 'file_top','title' => 'Select Uniform Top','col' => 'col-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('user.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'file_top','title' => 'Select Uniform Top','col' => 'col-4']); ?>
            <option value="polo" <?php echo e(old('file_top') === 'polo' ? 'selected' : ''); ?>>Polo
            </option>
            <option value="blouse" <?php echo e(old('file_top') === 'blouse' ? 'selected' : ''); ?>>Blouse
            </option>
            <option value="vest" <?php echo e(old('file_top') === 'vest' ? 'selected' : ''); ?>>Vest
            </option>
            <option value="blazer" <?php echo e(old('file_top') === 'blazer' ? 'selected' : ''); ?>>Blazer
            </option>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald66f0cbab223ac1c229ab0c4874ff3f9)): ?>
<?php $attributes = $__attributesOriginald66f0cbab223ac1c229ab0c4874ff3f9; ?>
<?php unset($__attributesOriginald66f0cbab223ac1c229ab0c4874ff3f9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald66f0cbab223ac1c229ab0c4874ff3f9)): ?>
<?php $component = $__componentOriginald66f0cbab223ac1c229ab0c4874ff3f9; ?>
<?php unset($__componentOriginald66f0cbab223ac1c229ab0c4874ff3f9); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginald66f0cbab223ac1c229ab0c4874ff3f9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald66f0cbab223ac1c229ab0c4874ff3f9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user.select','data' => ['name' => 'file_bottom','title' => 'Select Uniform Bottom','col' => 'col-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('user.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'file_bottom','title' => 'Select Uniform Bottom','col' => 'col-4']); ?>
            <option value="short" <?php echo e(old('file_bottom') === 'short' ? 'selected' : ''); ?>>Short
            </option>
            <option value="pants" <?php echo e(old('file_bottom') === 'pants' ? 'selected' : ''); ?>>Pants
            </option>
            <option value="skirt" <?php echo e(old('file_bottom') === 'skirt' ? 'selected' : ''); ?>>Skirt
            </option>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald66f0cbab223ac1c229ab0c4874ff3f9)): ?>
<?php $attributes = $__attributesOriginald66f0cbab223ac1c229ab0c4874ff3f9; ?>
<?php unset($__attributesOriginald66f0cbab223ac1c229ab0c4874ff3f9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald66f0cbab223ac1c229ab0c4874ff3f9)): ?>
<?php $component = $__componentOriginald66f0cbab223ac1c229ab0c4874ff3f9; ?>
<?php unset($__componentOriginald66f0cbab223ac1c229ab0c4874ff3f9); ?>
<?php endif; ?>
    </div>
    <div class="d-flex gap-3 w-100">
        <div class="col-6">
            <input type="text" class="form-control w-100" name="file_quantity" id="file_quantity" value="<?php echo e(old('quantity')); ?>"
            placeholder="Quantity">
             <?php $__errorArgs = ['file_quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <?php if (isset($component)) { $__componentOriginald66f0cbab223ac1c229ab0c4874ff3f9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald66f0cbab223ac1c229ab0c4874ff3f9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user.select','data' => ['name' => 'file_size','title' => 'Select Size']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('user.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'file_size','title' => 'Select Size']); ?>
            <option value="small" <?php echo e(old('file_size') === 'small' ? 'selected' : ''); ?>>small
            </option>
            <option value="medium" <?php echo e(old('file_size') === 'medium' ? 'selected' : ''); ?>>medium
            </option>
            <option value="large" <?php echo e(old('file_size') === 'large' ? 'selected' : ''); ?>>large
            </option>
            <option value="extra large" <?php echo e(old('file_size') === 'extra large' ? 'selected' : ''); ?>>extra large
            </option>

         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald66f0cbab223ac1c229ab0c4874ff3f9)): ?>
<?php $attributes = $__attributesOriginald66f0cbab223ac1c229ab0c4874ff3f9; ?>
<?php unset($__attributesOriginald66f0cbab223ac1c229ab0c4874ff3f9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald66f0cbab223ac1c229ab0c4874ff3f9)): ?>
<?php $component = $__componentOriginald66f0cbab223ac1c229ab0c4874ff3f9; ?>
<?php unset($__componentOriginald66f0cbab223ac1c229ab0c4874ff3f9); ?>
<?php endif; ?>
    </div>

    <div class="mt-3">
        <label for="formFile" class="form-label">Upload File</label>
        <input class="form-control" type="file" multiple name="file[]" id="formFile">
        <?php $__errorArgs = ['file.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="text-danger"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="text-danger"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<?php /**PATH C:\Users\TourismoPH\Herd\mmrc_tailoring\resources\views/components/uniform-upload-order-ready-made.blade.php ENDPATH**/ ?>
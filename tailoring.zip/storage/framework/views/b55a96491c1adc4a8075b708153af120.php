<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['title' => '']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['title' => '']); ?>
<?php foreach (array_filter((['title' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Tailoring - <?php echo e($title); ?></title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,600&display=swap" rel="stylesheet" />

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <link rel="stylesheet" href="<?php echo e(asset('assets/css/welcome.css')); ?>">

    <?php echo $__env->yieldPushContent('styles'); ?>

</head>

<body class="antialiased">
    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php if (isset($component)) { $__componentOriginalcdb273b5447a4a561c79b835ec9a524d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcdb273b5447a4a561c79b835ec9a524d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.user.partials.header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.user.partials.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcdb273b5447a4a561c79b835ec9a524d)): ?>
<?php $attributes = $__attributesOriginalcdb273b5447a4a561c79b835ec9a524d; ?>
<?php unset($__attributesOriginalcdb273b5447a4a561c79b835ec9a524d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcdb273b5447a4a561c79b835ec9a524d)): ?>
<?php $component = $__componentOriginalcdb273b5447a4a561c79b835ec9a524d; ?>
<?php unset($__componentOriginalcdb273b5447a4a561c79b835ec9a524d); ?>
<?php endif; ?>

    <?php echo e($slot); ?>


    <!-- Modal -->
    <div class="modal fade" id="orderModal" tabindex="-1" aria-labelledby="orderModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="orderModalLabel">Choose Order</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="d-flex justify-content-lg-around align-items-center">
                        <a href="<?php echo e(route('user.order.index', ['order_type' => 'customized'])); ?>" type="button"
                            class="btn btn-primary">
                            <i class="bi bi-scissors"></i> Customized
                        </a>
                        <a href="<?php echo e(route('user.order.index', ['order_type' => 'ready_made'])); ?>" type="button"
                            class="btn btn-secondary">
                            <i class="bi bi-box-seam"></i> Ready Made
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous">
    </script>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const orderBtns = document.querySelectorAll('.orderNow');

            orderBtns.forEach(function(orderBtn) {
                orderBtn.onclick = function() {
                    const orderModal = new bootstrap.Modal(document.getElementById('orderModal'));
                    orderModal.show();
                }
            });
        });
    </script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html>
<?php /**PATH C:\Users\TourismoPH\Herd\mmrc_tailoring\resources\views/components/layouts/user/app.blade.php ENDPATH**/ ?>
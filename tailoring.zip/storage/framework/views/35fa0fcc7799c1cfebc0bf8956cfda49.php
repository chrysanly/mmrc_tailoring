<?php $__env->startPush('styles'); ?>
    <style>
        #make-order {
            height: 100vh;
            background: #f8f9fa;
        }

        .card-header {
            color: #fff;
            background-color: #343a40;
        }

        .bg-primary {
            background-color: #343a40 !important;
            color: #fff;
        }

        .alert-warning {
            background-color: #ffc107;
            color: #212529;
        }

        .alert-danger,
        .alert-success {
            color: #fff;
        }

        .alert-danger {
            background-color: #dc3545;
        }

        .alert-success {
            background-color: #28a745;
        }

        .payment-method {
            border: 1px solid #dee2e6;
            border-radius: 0.25rem;
            padding: 1rem;
            text-align: center;
        }

        .payment-method h1 {
            font-size: 1.5rem;
            margin-bottom: 0.5rem;
        }

        .payment-method span {
            display: block;
            margin-bottom: 0.25rem;
        }

        .order-description h6 {
            margin-bottom: 0.5rem;
        }

        .order-summary {
            background-color: #343a40;
            color: #fff;
            padding: 0.5rem 1rem;
            border-radius: 0.25rem;
        }

        .order-summary span {
            margin-right: 1rem;
        }

        .upload-receipt {
            margin-top: 1rem;
        }

        .upload-receipt label {
            font-weight: bold;
        }

        .upload-receipt input {
            margin-top: 0.5rem;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php if (isset($component)) { $__componentOriginald25f66d794d63b85731f7b7b82d7b54e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald25f66d794d63b85731f7b7b82d7b54e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.user.app','data' => ['title' => 'Order']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.user.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Order']); ?>

    <section class="container mb-5">
        <div class="d-flex justify-content-around align-items-start gap-3">
            <div class="card col-8">
                <div class="card-header">Payment Description</div>
                <div class="card-body">
                    <div class="alert alert-warning"><b>Note</b>: 50% down payment is strictly required to process
                        your
                        order.</div>

                    <div class="order-description my-4 p-3 border rounded">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <h5 class="mb-3 text-primary">Order Description</h5>
                                <?php if(count($order->file_url) < 0): ?>
                                    <div class="text-start">
                                        <h6><b>Order Type:</b> <?php echo e($order->order_type); ?></h6>
                                        <h6><b>School:</b> <?php echo e($order->school); ?></h6>
                                        <h6><b>Top:</b> <?php echo e($order->top); ?></h6>
                                        <?php if(isset($order->bottom)): ?>
                                            <h6><b>Bottom:</b> <?php echo e($order->bottom); ?></h6>
                                        <?php endif; ?>
                                        <h6><b>Set:</b> <?php echo e($order->set); ?></h6>
                                        <h5 class="text-primary mt-4">Additional Items</h5>
                                        <h6><b>Threads:</b> <?php echo e($order->additionalItems->threads ?? 0); ?></h6>
                                        <h6><b>Zipper:</b> <?php echo e($order->additionalItems->zipper ?? 0); ?></h6>
                                        <h6><b>School Seal:</b> <?php echo e($order->additionalItems->school_seal ?? 0); ?></h6>
                                        <h6><b>Buttons:</b> <?php echo e($order->additionalItems->buttons ?? 0); ?></h6>
                                        <h6><b>Hook and Eye:</b> <?php echo e($order->additionalItems->hook_and_eye ?? 0); ?></h6>
                                        <h6><b>Tela:</b> <?php echo e($order->additionalItems->tela ?? 0); ?></h6>
                                    </div>
                                <?php else: ?>
                                 <div class="d-flex justify-content-evenly gap-3">
                                    <div class="text-start">
                                        <h6><b>Order Type:</b> <?php echo e($order->order_type); ?></h6>
                                        <h6><b>School:</b> <?php echo e($order->school); ?></h6>
                                        <h6><b>Top:</b> <?php echo e($order->top); ?></h6>
                                        <?php if(isset($order->bottom)): ?>
                                            <h6><b>Bottom:</b> <?php echo e($order->bottom); ?></h6>
                                        <?php endif; ?>
                                        <h6><b>Set:</b> <?php echo e($order->set); ?></h6>
                                        <h5 class="text-primary mt-4">Additional Items</h5>
                                        <h6><b>Threads:</b> <?php echo e($order->additionalItems->threads ?? 0); ?></h6>
                                        <h6><b>Zipper:</b> <?php echo e($order->additionalItems->zipper ?? 0); ?></h6>
                                        <h6><b>School Seal:</b> <?php echo e($order->additionalItems->school_seal ?? 0); ?></h6>
                                        <h6><b>Buttons:</b> <?php echo e($order->additionalItems->buttons ?? 0); ?></h6>
                                        <h6><b>Hook and Eye:</b> <?php echo e($order->additionalItems->hook_and_eye ?? 0); ?></h6>
                                        <h6><b>Tela:</b> <?php echo e($order->additionalItems->tela ?? 0); ?></h6>
                                    </div>
                                    <div class="text-center">
                                        <div class="d-flex flex-column">
                                            <?php $__currentLoopData = $order->file_url; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <a href="<?php echo e($file); ?>" target="_blank">
                                                    <img src="<?php echo e($file); ?>" alt="Order Image"
                                                        class="img-thumbnail" width="150" height="150">
                                                </a>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                 </div>
                                <?php endif; ?>
                            </div>

                            <div class="d-flex justify-content-end">
                                <div class="order-summary d-flex flex-column gap-3 align-items-end py-1 px-2 rounded">

                                    <span><b>Top</b>:
                                        ₱<?php echo e(number_format($order->invoice->top_price ?? 0, 2)); ?></span>
                                    <span><b>Bottom</b>:
                                        ₱<?php echo e(number_format($order->invoice->bottom_price ?? 0, 2)); ?></span>
                                    <span><b>Set</b>:
                                        ₱<?php echo e(number_format($order->invoice->set_price ?? 0, 2)); ?></span>
                                    <span><b>Additional Items</b>:
                                        ₱<?php echo e(number_format($order->invoice->additional_price ?? 0, 2)); ?></span>
                                    <?php if($order->invoice->discount): ?>
                                        <span><b>Discount</b>:
                                        <?php echo e(number_format($order->invoice->discount ?? 0, 2)); ?>%</span>
                                    <?php endif; ?>
                                    
                                    <span><b>Sub Total</b>:
                                        ₱<?php echo e(number_format($order->invoice->total ?? 0, 2)); ?></span>
                                    <span><b>Total Paid</b>:
                                        ₱<?php echo e(number_format($order->invoice->total_payment ?? 0, 2)); ?></span>
                                    <span><b>Total</b>:
                                        ₱<?php echo e(number_format(max(($order->invoice->total ?? 0) - ($order->invoice->total_payment ?? 0), 0), 2)); ?></span>

                                    <?php if(Str::lower($order->payment_status) === 'unpaid' || Str::lower($order->payment_status) === 'down-payment'): ?>
                                        <div class="border text-center my-0 p-0" style="width: 100%"></div>
                                    <?php endif; ?>
                                    <div class="align-self-center">
                                        <?php if(Str::lower($order->payment_status) === 'unpaid'): ?>
                                            <div class="text-warning"><b>Down Payment</b>:
                                                ₱<?php echo e(number_format($order->invoice->total / 2 ?? 0, 2)); ?></div>
                                        <?php endif; ?>
                                        <?php if(Str::lower($order->payment_status) === 'down payment'): ?>
                                            <div class="text-warning"><b>Balance</b>:
                                                ₱<?php echo e(number_format($order->invoice->total / 2 ?? 0, 2)); ?></div>
                                        <?php endif; ?>
                                        <?php if(Str::lower($order->payment_status) === 'settlement payment'): ?>
                                            <div class="text-warning"><b>Balance</b>:
                                                ₱<?php echo e(number_format($order->invoice->total - $order->invoice->total_payment ?? 0, 2)); ?>

                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <hr>

                    <div>
                        <h5>Payment Methods</h5>
                        <div class="d-flex justify-content-around gap-5 mb-3">
                            <?php $__currentLoopData = $paymentOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paymentOption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="payment-method">
                                    <h1><?php echo e($paymentOption->name); ?></h1>
                                    <span><b>Account Number:</b> <?php echo e($paymentOption->account_number); ?></span>
                                    <span><b>Account Name:</b> <?php echo e($paymentOption->account_name); ?></span>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                    </div>
                </div>
            </div>
            <?php if(!$order->invoice->is_paid): ?>
                <div class="card col-4">
                    <div class="card-header">Payment Form</div>
                    <div class="card-body">

                        <form action="<?php echo e(route('user.order.store-payment', $order)); ?>" method="post"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'amount','type' => 'text','label' => 'Amount to Pay']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'amount','type' => 'text','label' => 'Amount to Pay']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'contact_number','type' => 'text','label' => 'Contact Number']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'contact_number','type' => 'text','label' => 'Contact Number']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'referrence_number','type' => 'text','label' => 'Referrence Number']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'referrence_number','type' => 'text','label' => 'Referrence Number']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'account_name','type' => 'text','label' => 'Account Name']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'account_name','type' => 'text','label' => 'Account Name']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>

                            <small class="text-secondary">Please upload your receipt to verify your payment.</small>
                            <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'file','type' => 'file','label' => 'Upload Receipt']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'file','type' => 'file','label' => 'Upload Receipt']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>

                            <button type="submit" class="w-100 btn btn-primary">Send Payment</button>
                        </form>
                    </div>
                </div>
            <?php endif; ?>

        </div>
    </section>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald25f66d794d63b85731f7b7b82d7b54e)): ?>
<?php $attributes = $__attributesOriginald25f66d794d63b85731f7b7b82d7b54e; ?>
<?php unset($__attributesOriginald25f66d794d63b85731f7b7b82d7b54e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald25f66d794d63b85731f7b7b82d7b54e)): ?>
<?php $component = $__componentOriginald25f66d794d63b85731f7b7b82d7b54e; ?>
<?php unset($__componentOriginald25f66d794d63b85731f7b7b82d7b54e); ?>
<?php endif; ?>
<?php /**PATH C:\Users\TourismoPH\Herd\mmrc_tailoring\resources\views/user/order/payment.blade.php ENDPATH**/ ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        const checkUploadFile = document.getElementById('checkUploadFile');
        const formUniformType = document.getElementById('uniform-type');
        const formUploadType = document.getElementById('upload-type');
        const formType = document.getElementById('form_type');

        const uniformTop = document.getElementById('top');
        const uniformBottom = document.getElementById('bottom');
        const uniformSet = document.getElementById('set');

        const hiddenTop = document.getElementById('hiddenTop');
        const hiddenBottom = document.getElementById('hiddenBottom');

        if (checkUploadFile) {
            checkUploadFile.addEventListener('change', function() {

                if (this.checked) {
                    formUniformType.style.display = 'none';
                    formUploadType.style.display = 'block';
                    formType.value = 'true';
                    uniformValuesAndState('', '');
                    uniformTop.disabled = false;
                    uniformBottom.disabled = false;
                } else {
                    formUniformType.style.display = 'block';
                    formUploadType.style.display = 'none';
                    formType.value = 'false';
                }
            });
        }

        uniformTop.addEventListener('change', function() {
            hiddenTop.value = this.value;
        })

        uniformBottom.addEventListener('change', function() {
            hiddenBottom.value = this.value;
        })

        uniformSet.addEventListener('change', function() {
            console.log(this.value);

            if (this.value === '' || this.value === 'custom') {
                uniformValuesAndState('', '');
                uniformTop.disabled = false;
                uniformBottom.disabled = false;
            } else {
                uniformTop.disabled = true;
                uniformBottom.disabled = true;

                if (this.value === 'set-1') {
                    uniformValuesAndState("polo", "pants");
                }
                if (this.value === 'set-2') {
                    uniformValuesAndState("vest", "short");
                }
                if (this.value === 'set-3') {
                    uniformValuesAndState("blazer", "skirt");
                }
            }

        })

        function uniformValuesAndState(top, bottom) {
            uniformTop.value = top;
            uniformBottom.value = bottom;

            // Sync hidden fields so Laravel receives the values
            hiddenTop.value = top;
            hiddenBottom.value = bottom;
        }

        function checkValue() {
            if (formType.value === 'true') {
                checkUploadFile.checked = true;
            } else {
                checkUploadFile.checked = false;
            }
        }

        function checkBehavior() {


            if (checkUploadFile.checked) {
                formUniformType.style.display = 'none';
                formUploadType.style.display = 'block';
                formType.value = 'true';

            } else {
                formUniformType.style.display = 'block';
                formUploadType.style.display = 'none';
                formType.value = 'false';
            }
        }

        if (checkUploadFile) {
            checkValue();
            checkBehavior();
        }
    </script>
<?php $__env->stopPush(); ?>

<div class="card" id="uniform-type">
    <div class="card-header">
        <h5>Uniform Type</h5>
    </div>
    <div class="card-body">
        <div class="d-flex justify-content-between align-items-center gap-2">
            <div class="d-flex flex-column gap-3 w-100">
                <?php if (isset($component)) { $__componentOriginald66f0cbab223ac1c229ab0c4874ff3f9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald66f0cbab223ac1c229ab0c4874ff3f9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user.select','data' => ['name' => 'set','title' => 'Select Uniform Set','col' => 'col-12']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('user.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'set','title' => 'Select Uniform Set','col' => 'col-12']); ?>
                    <option value="custom" <?php echo e(old('set') === 'custom' ? 'selected' : ''); ?>>Custom
                    </option>
                    <option value="set-1" <?php echo e(old('set') === 'set-1' ? 'selected' : ''); ?>>Set of
                        Uniform</option>
                    <option value="set-2" <?php echo e(old('set') === 'set-2' ? 'selected' : ''); ?>>Set of
                        Uniform with Vest</option>
                    <option value="set-3" <?php echo e(old('set') === 'set-3' ? 'selected' : ''); ?>>Set of
                        Uniform with Blazer</option>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald66f0cbab223ac1c229ab0c4874ff3f9)): ?>
<?php $attributes = $__attributesOriginald66f0cbab223ac1c229ab0c4874ff3f9; ?>
<?php unset($__attributesOriginald66f0cbab223ac1c229ab0c4874ff3f9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald66f0cbab223ac1c229ab0c4874ff3f9)): ?>
<?php $component = $__componentOriginald66f0cbab223ac1c229ab0c4874ff3f9; ?>
<?php unset($__componentOriginald66f0cbab223ac1c229ab0c4874ff3f9); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginald66f0cbab223ac1c229ab0c4874ff3f9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald66f0cbab223ac1c229ab0c4874ff3f9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user.select','data' => ['name' => 'top','title' => 'Select Uniform Top','col' => 'col-12']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('user.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'top','title' => 'Select Uniform Top','col' => 'col-12']); ?>
                    <option value="polo" <?php echo e(old('top') === 'polo' ? 'selected' : ''); ?>>Polo
                    </option>
                    <option value="blouse" <?php echo e(old('top') === 'blouse' ? 'selected' : ''); ?>>Blouse
                    </option>
                    <option value="vest" <?php echo e(old('top') === 'vest' ? 'selected' : ''); ?>>Vest
                    </option>
                    <option value="blazer" <?php echo e(old('top') === 'blazer' ? 'selected' : ''); ?>>Blazer
                    </option>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald66f0cbab223ac1c229ab0c4874ff3f9)): ?>
<?php $attributes = $__attributesOriginald66f0cbab223ac1c229ab0c4874ff3f9; ?>
<?php unset($__attributesOriginald66f0cbab223ac1c229ab0c4874ff3f9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald66f0cbab223ac1c229ab0c4874ff3f9)): ?>
<?php $component = $__componentOriginald66f0cbab223ac1c229ab0c4874ff3f9; ?>
<?php unset($__componentOriginald66f0cbab223ac1c229ab0c4874ff3f9); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginald66f0cbab223ac1c229ab0c4874ff3f9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald66f0cbab223ac1c229ab0c4874ff3f9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user.select','data' => ['name' => 'bottom','title' => 'Select Uniform Bottom','col' => 'col-12']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('user.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'bottom','title' => 'Select Uniform Bottom','col' => 'col-12']); ?>
                    <option value="short" <?php echo e(old('bottom') === 'short' ? 'selected' : ''); ?>>Short
                    </option>
                    <option value="pants" <?php echo e(old('bottom') === 'pants' ? 'selected' : ''); ?>>Pants
                    </option>
                    <option value="skirt" <?php echo e(old('bottom') === 'skirt' ? 'selected' : ''); ?>>Skirt
                    </option>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald66f0cbab223ac1c229ab0c4874ff3f9)): ?>
<?php $attributes = $__attributesOriginald66f0cbab223ac1c229ab0c4874ff3f9; ?>
<?php unset($__attributesOriginald66f0cbab223ac1c229ab0c4874ff3f9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald66f0cbab223ac1c229ab0c4874ff3f9)): ?>
<?php $component = $__componentOriginald66f0cbab223ac1c229ab0c4874ff3f9; ?>
<?php unset($__componentOriginald66f0cbab223ac1c229ab0c4874ff3f9); ?>
<?php endif; ?>
            </div>
            <div class="d-flex flex-column gap-3 w-100">
                <div class="col-6 w-100">
                    <input type="text" class="form-control" name="quantity" value="<?php echo e(old('quantity')); ?>"
                    placeholder="Quantity">
                <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <?php if (isset($component)) { $__componentOriginald66f0cbab223ac1c229ab0c4874ff3f9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald66f0cbab223ac1c229ab0c4874ff3f9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user.select','data' => ['name' => 'school','title' => 'Select School','col' => 'col-12']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('user.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'school','title' => 'Select School','col' => 'col-12']); ?>
                    <option value="WMSU" <?php echo e(old('school') === 'WMSU' ? 'selected' : ''); ?>>WMSU
                    </option>
                    <option value="ZPPSU" <?php echo e(old('school') === 'ZPPSU' ? 'selected' : ''); ?>>ZPPSU
                    </option>
                    <option value="SOUTHERN" <?php echo e(old('school') === 'SOUTHERN' ? 'selected' : ''); ?>>
                        SOUTHERN</option>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald66f0cbab223ac1c229ab0c4874ff3f9)): ?>
<?php $attributes = $__attributesOriginald66f0cbab223ac1c229ab0c4874ff3f9; ?>
<?php unset($__attributesOriginald66f0cbab223ac1c229ab0c4874ff3f9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald66f0cbab223ac1c229ab0c4874ff3f9)): ?>
<?php $component = $__componentOriginald66f0cbab223ac1c229ab0c4874ff3f9; ?>
<?php unset($__componentOriginald66f0cbab223ac1c229ab0c4874ff3f9); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginald66f0cbab223ac1c229ab0c4874ff3f9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald66f0cbab223ac1c229ab0c4874ff3f9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user.select','data' => ['name' => 'size','title' => 'Select Size','col' => 'col-12']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('user.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'size','title' => 'Select Size','col' => 'col-12']); ?>
                    <option value="small" <?php echo e(old('size') === 'small' ? 'selected' : ''); ?>>small
                    </option>
                    <option value="medium" <?php echo e(old('size') === 'medium' ? 'selected' : ''); ?>>medium
                    </option>
                    <option value="large" <?php echo e(old('size') === 'large' ? 'selected' : ''); ?>>large
                    </option>
                    <option value="extra large" <?php echo e(old('size') === 'extra large' ? 'selected' : ''); ?>>extra large
                    </option>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald66f0cbab223ac1c229ab0c4874ff3f9)): ?>
<?php $attributes = $__attributesOriginald66f0cbab223ac1c229ab0c4874ff3f9; ?>
<?php unset($__attributesOriginald66f0cbab223ac1c229ab0c4874ff3f9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald66f0cbab223ac1c229ab0c4874ff3f9)): ?>
<?php $component = $__componentOriginald66f0cbab223ac1c229ab0c4874ff3f9; ?>
<?php unset($__componentOriginald66f0cbab223ac1c229ab0c4874ff3f9); ?>
<?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\TourismoPH\Herd\mmrc_tailoring\resources\views/components/ready-made-uniform-type.blade.php ENDPATH**/ ?>
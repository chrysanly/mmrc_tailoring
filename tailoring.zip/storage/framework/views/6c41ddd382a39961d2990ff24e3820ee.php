<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['modalId' => 'exampleModal', 'size' => '', 'confirmButtonLabel' => 'Save Changes', 'modalConfirmId' => '', 'buttonLabel' => 'Label', 'isButton' => false]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['modalId' => 'exampleModal', 'size' => '', 'confirmButtonLabel' => 'Save Changes', 'modalConfirmId' => '', 'buttonLabel' => 'Label', 'isButton' => false]); ?>
<?php foreach (array_filter((['modalId' => 'exampleModal', 'size' => '', 'confirmButtonLabel' => 'Save Changes', 'modalConfirmId' => '', 'buttonLabel' => 'Label', 'isButton' => false]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<button type="button" class="<?php echo e($isButton ? 'btn btn-primary btn-sm' : 'dropdown-item'); ?>" onclick="openModal()"><?php echo e($buttonLabel); ?></button>

<!-- Modal -->
<div class="modal fade" id="<?php echo e($modalId); ?>" tabindex="-1" aria-labelledby="<?php echo e($modalId); ?>Label" aria-hidden="true">
  <div class="modal-dialog <?php echo e($size); ?>">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="<?php echo e($modalId); ?>Label">Modal title</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <?php echo e($slot); ?>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" id="<?php echo e($modalConfirmId); ?>" class="btn btn-primary"><?php echo e($confirmButtonLabel); ?></button>
      </div>
    </div>
  </div>
</div><?php /**PATH C:\Users\TourismoPH\Herd\mmrc_tailoring\resources\views/components/admin/modal-button.blade.php ENDPATH**/ ?>
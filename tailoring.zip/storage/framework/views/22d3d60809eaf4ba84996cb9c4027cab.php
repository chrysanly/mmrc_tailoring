<?php $__env->startPush('styles'); ?>
    <style>
        .card-header {
            color: var(--white-color);
            background-color: var(--dark-color);
        }

        .form-check-input {
            border: 1px solid var(--dark-color);
        }

        .form-check-input:checked {
            background-color: var(--red-color);
            border-color: var(--red-color);
        }

        .alert-danger1 {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }

        #set-of-uniform,
        #set-of-uniform-with-vest,
        #set-of-uniform-with-blazer,
        #upload-type {
            display: none;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php if (isset($component)) { $__componentOriginald25f66d794d63b85731f7b7b82d7b54e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald25f66d794d63b85731f7b7b82d7b54e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.user.app','data' => ['title' => 'Order']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.user.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Order']); ?>

    <section id="make-order">
        <div class="container py-5">
            <h1 class="text-center fw-bold">Order Ready Made</h1>

            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <?php if(session('error')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <form class="mb-4" action="<?php echo e(route('user.order.store.ready-made')); ?>" method="post"
                enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-check py-3">
                    <input class="form-check-input" type="checkbox" value="" id="checkUploadFile">
                    <label class="form-check-label fw-bold" for="checkUploadFile">
                        File upload for order ?
                    </label>
                </div>

                <input type="hidden" name="form_type" id="form_type" value="<?php echo e(old('form_type')); ?>">
                <input type="hidden" name="order_type" value="customized">

                <div class="d-flex justify-content-around gap-3 align-items-start">
                    <div class="d-flex flex-column gap-3 col-8">
                        <div class="card">
                            <div class="card-header">
                                <h5>Guide on how to measure yourself</h5>
                            </div>
                            <div class="card-body">

                                <div class="d-flex justify-content-around gap-4">
                                    <img src="<?php echo e(asset('assets/images/pants.png')); ?>" width="150" height="150"
                                        alt="pants-measure">
                                    <img src="<?php echo e(asset('assets/images/polo.png')); ?>" width="150" height="150"
                                        alt="polo-measure">
                                </div>
                            </div>
                        </div>
                        <?php if (isset($component)) { $__componentOriginal0904f78518509ea59987d272d5829b58 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0904f78518509ea59987d272d5829b58 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ready-made-uniform-type','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ready-made-uniform-type'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0904f78518509ea59987d272d5829b58)): ?>
<?php $attributes = $__attributesOriginal0904f78518509ea59987d272d5829b58; ?>
<?php unset($__attributesOriginal0904f78518509ea59987d272d5829b58); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0904f78518509ea59987d272d5829b58)): ?>
<?php $component = $__componentOriginal0904f78518509ea59987d272d5829b58; ?>
<?php unset($__componentOriginal0904f78518509ea59987d272d5829b58); ?>
<?php endif; ?>
                        <div class="card" id="upload-type">
                            <?php if (isset($component)) { $__componentOriginal71974895fef2a394b2e697fc2b9bc807 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal71974895fef2a394b2e697fc2b9bc807 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.uniform-upload-order-ready-made','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('uniform-upload-order-ready-made'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal71974895fef2a394b2e697fc2b9bc807)): ?>
<?php $attributes = $__attributesOriginal71974895fef2a394b2e697fc2b9bc807; ?>
<?php unset($__attributesOriginal71974895fef2a394b2e697fc2b9bc807); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71974895fef2a394b2e697fc2b9bc807)): ?>
<?php $component = $__componentOriginal71974895fef2a394b2e697fc2b9bc807; ?>
<?php unset($__componentOriginal71974895fef2a394b2e697fc2b9bc807); ?>
<?php endif; ?>
                        </div>

                        <?php echo $__env->make('user.order.additional-items', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <input type="hidden" name="top" id="hiddenTop" value="<?php echo e(old('top')); ?>">
                        <input type="hidden" name="bottom" id="hiddenBottom" value="<?php echo e(old('bottom')); ?>">
                        <button type="submit" class="btn btn-primary">Submit Order</button>
                    </div>
                    <?php echo $__env->make('user.order.uniform_prices', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </form>

        </div>
    </section>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald25f66d794d63b85731f7b7b82d7b54e)): ?>
<?php $attributes = $__attributesOriginald25f66d794d63b85731f7b7b82d7b54e; ?>
<?php unset($__attributesOriginald25f66d794d63b85731f7b7b82d7b54e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald25f66d794d63b85731f7b7b82d7b54e)): ?>
<?php $component = $__componentOriginald25f66d794d63b85731f7b7b82d7b54e; ?>
<?php unset($__componentOriginald25f66d794d63b85731f7b7b82d7b54e); ?>
<?php endif; ?>
<?php /**PATH C:\Users\TourismoPH\Herd\mmrc_tailoring\resources\views/user/order/ready_made.blade.php ENDPATH**/ ?>
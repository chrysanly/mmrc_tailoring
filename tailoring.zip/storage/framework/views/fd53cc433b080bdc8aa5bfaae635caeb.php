<?php $__env->startSection('title', 'Appointment'); ?>

<?php $__env->startSection('content'); ?>
     <section id="make-appointment">
        <div class="container py-5">
            <h1 class="text-center fw-bold">Make an Appointment</h1>
           
            <div id='calendar' class="mb-5"></div>
            <span id="max_limit" style="display: none;"><?php echo e($limit); ?></span>
        </div>
    </section>

    <!-- Modal -->
<div class="modal fade" id="confirmationModal" tabindex="-1" aria-labelledby="confirmationModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="confirmationModalLabel">Confirm Appointment</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                You have selected <span id="modalDate" class="text-danger fw-bolder"></span>. Do you want to confirm
                this appointment?
                
                    <input type="hidden" id="selectedDate">
                    <?php if (isset($component)) { $__componentOriginalddd4aa2858d381360033468f376a3dfc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalddd4aa2858d381360033468f376a3dfc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user.input-field','data' => ['type' => 'time','name' => 'from','label' => 'Time From','class' => 'w-100']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('user.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'time','name' => 'from','label' => 'Time From','class' => 'w-100']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalddd4aa2858d381360033468f376a3dfc)): ?>
<?php $attributes = $__attributesOriginalddd4aa2858d381360033468f376a3dfc; ?>
<?php unset($__attributesOriginalddd4aa2858d381360033468f376a3dfc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalddd4aa2858d381360033468f376a3dfc)): ?>
<?php $component = $__componentOriginalddd4aa2858d381360033468f376a3dfc; ?>
<?php unset($__componentOriginalddd4aa2858d381360033468f376a3dfc); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginalddd4aa2858d381360033468f376a3dfc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalddd4aa2858d381360033468f376a3dfc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user.input-field','data' => ['type' => 'time','name' => 'to','label' => 'Time To']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('user.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'time','name' => 'to','label' => 'Time To']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalddd4aa2858d381360033468f376a3dfc)): ?>
<?php $attributes = $__attributesOriginalddd4aa2858d381360033468f376a3dfc; ?>
<?php unset($__attributesOriginalddd4aa2858d381360033468f376a3dfc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalddd4aa2858d381360033468f376a3dfc)): ?>
<?php $component = $__componentOriginalddd4aa2858d381360033468f376a3dfc; ?>
<?php unset($__componentOriginalddd4aa2858d381360033468f376a3dfc); ?>
<?php endif; ?>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary" id="appointmentForm">Confirm</button>
            </div>
        </div>
    </div>
</div>


    <!-- Modal -->
<div class="modal fade" id="appointmentGuideModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="appointmentGuideModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
           
            <div class="modal-body">
                
                <div class="d-flex justify-content-between align-items-center">
                    <p class="fw-bold mt-2">APPOINTMENT GUIDES:</p>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
              <ol>
                <li>Choose a date from the calendar.</li>
                <li>
                    Select the available date:
                    <ul>
                        <li>Red <div style="width: 15px; height: 10px; background-color: red; display: inline-block; border: 1px solid black;"></div> Background means full appointment</li>
                        <li>White <div style="width: 15px; height: 10px; background-color: white; display: inline-block; border: 1px solid black;"></div> Background means available appointment</li>
                        <li>Gray <div style="width: 15px; height: 10px; background-color: gray; display: inline-block; border: 1px solid black;"></div> Background means past date</li>
                    </ul>
                </li>
                <li>
                    Choose start time and end time of appointment and select <b>Confirm</b> button.
                </li>
              </ol>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/user/css/appointment.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.15/index.global.min.js"></script>
    <script>
        const postRoute = "<?php echo e(route('user.appointment.store')); ?>";
    </script>
    <script src="<?php echo e(asset('assets/user/js/appointment.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.user.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TourismoPH\Herd\mmrc_tailoring\resources\views/user/appointment/index.blade.php ENDPATH**/ ?>
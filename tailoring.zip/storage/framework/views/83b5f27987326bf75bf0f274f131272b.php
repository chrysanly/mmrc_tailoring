 <?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['id' => '', 'status' => '', 'button' => '']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['id' => '', 'status' => '', 'button' => '']); ?>
<?php foreach (array_filter((['id' => '', 'status' => '', 'button' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
 
 <form
     action="<?php echo e(route('admin.appointment.update-status', [
         'appointment' => $id,
         'status' => $status,
     ])); ?>"
     method="post">
     <?php echo csrf_field(); ?>
     <?php echo method_field('PATCH'); ?>
     <button type="submit" class="dropdown-item"><?php echo e($button); ?></button>
 </form>
<?php /**PATH C:\Users\TourismoPH\Herd\mmrc_tailoring\resources\views/components/admin/appointment-update-status.blade.php ENDPATH**/ ?>
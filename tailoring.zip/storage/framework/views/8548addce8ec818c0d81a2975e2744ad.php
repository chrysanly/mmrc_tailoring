<div class="card col-6 d-none" id="polo-measurement">
    <div class="card-header">
        <h5>Polo Measurement</h5>
    </div>
    <div class="card-body">

        <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'polo_chest','type' => 'number','label' => 'Chest (inches)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'polo_chest','type' => 'number','label' => 'Chest (inches)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'polo_length','type' => 'number','label' => 'Polo\'s Length (inches)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'polo_length','type' => 'number','label' => 'Polo\'s Length (inches)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'polo_hips','type' => 'number','label' => 'Hips (inches)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'polo_hips','type' => 'number','label' => 'Hips (inches)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'polo_shoulder','type' => 'number','label' => 'Shoulder Measurement (inches)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'polo_shoulder','type' => 'number','label' => 'Shoulder Measurement (inches)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'polo_sleeve','type' => 'number','label' => 'Sleeve Length (inches)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'polo_sleeve','type' => 'number','label' => 'Sleeve Length (inches)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'polo_armhole','type' => 'number','label' => 'Armhole (inches)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'polo_armhole','type' => 'number','label' => 'Armhole (inches)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'polo_lower_arm_girth','type' => 'number','label' => 'Lower Arm Girth (inches)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'polo_lower_arm_girth','type' => 'number','label' => 'Lower Arm Girth (inches)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
    </div>
</div>

<div class="card col-6 d-none" id="pants-measurement">
    <div class="card-header">
        <h5>Pants Measurement</h5>
    </div>
    <div class="card-body">

        <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'pants_length','type' => 'number','label' => 'Pants Length (inches)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'pants_length','type' => 'number','label' => 'Pants Length (inches)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'pants_waist','type' => 'number','label' => 'Waist (inches)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'pants_waist','type' => 'number','label' => 'Waist (inches)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'pants_hips','type' => 'number','label' => 'Hip (inches)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'pants_hips','type' => 'number','label' => 'Hip (inches)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'pants_scrotch','type' => 'number','label' => 'Crotch (inches)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'pants_scrotch','type' => 'number','label' => 'Crotch (inches)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'pants_knee_height','type' => 'number','label' => 'Knee Height (inches)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'pants_knee_height','type' => 'number','label' => 'Knee Height (inches)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'pants_knee_circumference','type' => 'number','label' => 'Knee Circumference (inches)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'pants_knee_circumference','type' => 'number','label' => 'Knee Circumference (inches)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'pants_bottom_circumferem','type' => 'number','label' => 'Bottom Circumference (inches)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'pants_bottom_circumferem','type' => 'number','label' => 'Bottom Circumference (inches)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
    </div>
</div>

<div class="card col-6 d-none" id="blazer-measurement">
    <div class="card-header">
        <h5>Blazer Measurement</h5>
    </div>
    <div class="card-body">
        <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'blazer_chest','type' => 'number','label' => 'Chest (inches)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'blazer_chest','type' => 'number','label' => 'Chest (inches)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'blazer_shoulder_width','type' => 'number','label' => 'Shoulder Width (inches)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'blazer_shoulder_width','type' => 'number','label' => 'Shoulder Width (inches)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'blazer_length','type' => 'number','label' => 'Blazer Length (inches)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'blazer_length','type' => 'number','label' => 'Blazer Length (inches)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'blazer_sleeve_length','type' => 'number','label' => 'Sleeve Length (inches)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'blazer_sleeve_length','type' => 'number','label' => 'Sleeve Length (inches)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'blazer_waist','type' => 'number','label' => 'Waist (inches)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'blazer_waist','type' => 'number','label' => 'Waist (inches)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'blazer_hips','type' => 'number','label' => 'Hips (inches)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'blazer_hips','type' => 'number','label' => 'Hips (inches)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'blazer_armhole','type' => 'number','label' => 'Armhole (inches)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'blazer_armhole','type' => 'number','label' => 'Armhole (inches)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'blazer_wrist','type' => 'number','label' => 'Wrist (inches)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'blazer_wrist','type' => 'number','label' => 'Wrist (inches)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'blazer_back_width','type' => 'number','label' => 'Back Width (inches)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'blazer_back_width','type' => 'number','label' => 'Back Width (inches)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'blazer_lower_arm_girth','type' => 'number','label' => 'Lower Arm Girth (inches)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'blazer_lower_arm_girth','type' => 'number','label' => 'Lower Arm Girth (inches)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
    </div>
</div>

<div class="card col-6 d-none" id="skirt-measurement">
    <div class="card-header">
        <h5>Skirt Measurement</h5>
    </div>
    <div class="card-body">
        <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'skirt_length','type' => 'number','label' => 'Skirt Length (inches)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'skirt_length','type' => 'number','label' => 'Skirt Length (inches)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'skirt_waist','type' => 'number','label' => 'Waist (inches)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'skirt_waist','type' => 'number','label' => 'Waist (inches)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'skirt_hips','type' => 'number','label' => 'Hips (inches)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'skirt_hips','type' => 'number','label' => 'Hips (inches)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'skirt_hip_depth','type' => 'number','label' => 'Hip Depth (inches)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'skirt_hip_depth','type' => 'number','label' => 'Hip Depth (inches)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
    </div>
</div>

<div class="card col-6 d-none" id="vest-measurement">
    <div class="card-header">
        <h5>Vest Measurement</h5>
    </div>
    <div class="card-body">
        <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'vest_armhole','type' => 'number','label' => 'Armhole (inches)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'vest_armhole','type' => 'number','label' => 'Armhole (inches)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'vest_full_length','type' => 'number','label' => 'Full Length (inches)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'vest_full_length','type' => 'number','label' => 'Full Length (inches)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'vest_shoulder_width','type' => 'number','label' => 'Shoulder Width (inches)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'vest_shoulder_width','type' => 'number','label' => 'Shoulder Width (inches)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'vest_neck_circumference','type' => 'number','label' => 'Neck Circumference (inches)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'vest_neck_circumference','type' => 'number','label' => 'Neck Circumference (inches)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
    </div>
</div>

<div class="card col-6 d-none" id="short-measurement">
    <div class="card-header">
        <h5>Short Measurement</h5>
    </div>
    <div class="card-body">

        <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'short_waist','type' => 'number','label' => 'Waist (inches)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'short_waist','type' => 'number','label' => 'Waist (inches)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'short_hips','type' => 'number','label' => 'Hip (inches)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'short_hips','type' => 'number','label' => 'Hip (inches)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'short_length','type' => 'number','label' => 'Short Length (inches)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'short_length','type' => 'number','label' => 'Short Length (inches)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'short_thigh_circumference','type' => 'number','label' => 'Thigh Circumference (inches)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'short_thigh_circumference','type' => 'number','label' => 'Thigh Circumference (inches)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'short_inseam_length','type' => 'number','label' => 'Inseam Length (inches)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'short_inseam_length','type' => 'number','label' => 'Inseam Length (inches)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'short_leg_opening','type' => 'number','label' => 'Leg Opening (inches)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'short_leg_opening','type' => 'number','label' => 'Leg Opening (inches)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'short_rise','type' => 'number','label' => 'Rise (inches)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'short_rise','type' => 'number','label' => 'Rise (inches)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
    </div>
</div>

<div class="card col-6 d-none" id="blouse-measurement">
    <div class="card-header">
        <h5>Blouse Measurement</h5>
    </div>
    <div class="card-body">
        <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'blouse_bust','type' => 'number','label' => 'Bust (inches)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'blouse_bust','type' => 'number','label' => 'Bust (inches)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'blouse_length','type' => 'number','label' => 'Blouse Length (inches)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'blouse_length','type' => 'number','label' => 'Blouse Length (inches)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'blouse_waist','type' => 'number','label' => 'Waist (inches)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'blouse_waist','type' => 'number','label' => 'Waist (inches)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'blouse_figure','type' => 'number','label' => 'Figure (inches)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'blouse_figure','type' => 'number','label' => 'Figure (inches)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'blouse_hips','type' => 'number','label' => 'Hips (inches)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'blouse_hips','type' => 'number','label' => 'Hips (inches)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'blouse_shoulder','type' => 'number','label' => 'Shoulder (inches)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'blouse_shoulder','type' => 'number','label' => 'Shoulder (inches)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'blouse_sleeve','type' => 'number','label' => 'Sleeve Length (inches)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'blouse_sleeve','type' => 'number','label' => 'Sleeve Length (inches)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'blouse_arm_hole','type' => 'number','label' => 'Arm Hole (inches)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'blouse_arm_hole','type' => 'number','label' => 'Arm Hole (inches)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal21b1e56167f84ef30e29c462e265a505 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b1e56167f84ef30e29c462e265a505 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input-field','data' => ['name' => 'blouse_lower_arm_girth','type' => 'number','label' => 'Lower Arm Girth (inches)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'blouse_lower_arm_girth','type' => 'number','label' => 'Lower Arm Girth (inches)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $attributes = $__attributesOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__attributesOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b1e56167f84ef30e29c462e265a505)): ?>
<?php $component = $__componentOriginal21b1e56167f84ef30e29c462e265a505; ?>
<?php unset($__componentOriginal21b1e56167f84ef30e29c462e265a505); ?>
<?php endif; ?>
    </div>
</div>


<?php /**PATH C:\Users\TourismoPH\Herd\mmrc_tailoring\resources\views/user/order/measurements_field.blade.php ENDPATH**/ ?>
<?php $__env->startPush('styles'); ?>
    <style>
        .card-header {
            color: var(--white-color);
            background-color: var(--dark-color);
        }

        .form-check-input {
            border: 1px solid var(--dark-color);
        }

        .form-check-input:checked {
            background-color: var(--red-color);
            border-color: var(--red-color);
        }

        .alert-danger1 {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }

        #set-of-uniform,
        #set-of-uniform-with-vest,
        #set-of-uniform-with-blazer,
        #upload-type {
            display: none;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php if (isset($component)) { $__componentOriginald25f66d794d63b85731f7b7b82d7b54e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald25f66d794d63b85731f7b7b82d7b54e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.user.app','data' => ['title' => 'Order']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.user.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Order']); ?>

    <section id="make-order">
        <div class="container py-5">
            <h1 class="text-center fw-bold">Make an Customized Order</h1>

            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <?php if(session('error')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <form class="mb-4" action="<?php echo e(route('user.order.store')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <div class="form-check py-3">
                    <input class="form-check-input" type="checkbox" value="" id="checkUploadFile">
                    <label class="form-check-label fw-bold" for="checkUploadFile">
                        File upload for order ?
                    </label>
                </div>

                <input type="hidden" name="form_type" id="form_type" value="<?php echo e(old('form_type')); ?>">
                <input type="hidden" name="order_type" value="customized">

                <div class="d-flex justify-content-around gap-3 align-items-start">
                    <div class="d-flex flex-column gap-3 col-8">
                        <div class="card">
                            <div class="card-header">
                                <h5>Guide on how to measure yourself</h5>
                            </div>
                            <div class="card-body">

                                <div class="d-flex justify-content-around gap-4">
                                    <a href="<?php echo e(asset('assets/images/pants.png')); ?>" target="__blank">
                                        <img src="<?php echo e(asset('assets/images/pants.png')); ?>"  width="150" height="150"
                                            alt="pants-measure">
                                    </a>
                                    <img src="<?php echo e(asset('assets/images/polo.png')); ?>" width="150" height="150"
                                        alt="polo-measure">
                                </div>
                            </div>
                        </div>
                        <?php if (isset($component)) { $__componentOriginal7c15a6f5bb5bc3b9f098ea07fcd663f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7c15a6f5bb5bc3b9f098ea07fcd663f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.uniform-type','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('uniform-type'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7c15a6f5bb5bc3b9f098ea07fcd663f6)): ?>
<?php $attributes = $__attributesOriginal7c15a6f5bb5bc3b9f098ea07fcd663f6; ?>
<?php unset($__attributesOriginal7c15a6f5bb5bc3b9f098ea07fcd663f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7c15a6f5bb5bc3b9f098ea07fcd663f6)): ?>
<?php $component = $__componentOriginal7c15a6f5bb5bc3b9f098ea07fcd663f6; ?>
<?php unset($__componentOriginal7c15a6f5bb5bc3b9f098ea07fcd663f6); ?>
<?php endif; ?>
                        <div class="card" id="upload-type">
                            <?php if (isset($component)) { $__componentOriginal3591c94a9235d345352e7a0adfe7cd1e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3591c94a9235d345352e7a0adfe7cd1e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.uniform-upload-order','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('uniform-upload-order'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3591c94a9235d345352e7a0adfe7cd1e)): ?>
<?php $attributes = $__attributesOriginal3591c94a9235d345352e7a0adfe7cd1e; ?>
<?php unset($__attributesOriginal3591c94a9235d345352e7a0adfe7cd1e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3591c94a9235d345352e7a0adfe7cd1e)): ?>
<?php $component = $__componentOriginal3591c94a9235d345352e7a0adfe7cd1e; ?>
<?php unset($__componentOriginal3591c94a9235d345352e7a0adfe7cd1e); ?>
<?php endif; ?>
                        </div>

                        <div class="d-flex gap-2 justify-content-between">
                            <?php echo $__env->make('user.order.measurements_field', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>

                        <input type="hidden" name="top" id="hiddenTop" value="<?php echo e(old('top')); ?>">
                        <input type="hidden" name="bottom" id="hiddenBottom" value="<?php echo e(old('bottom')); ?>">

                        <?php echo $__env->make('user.order.additional-items', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <button type="submit" class="btn btn-primary">Submit Order</button>
                    </div>
                    <?php echo $__env->make('user.order.uniform_prices', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </form>

        </div>
    </section>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald25f66d794d63b85731f7b7b82d7b54e)): ?>
<?php $attributes = $__attributesOriginald25f66d794d63b85731f7b7b82d7b54e; ?>
<?php unset($__attributesOriginald25f66d794d63b85731f7b7b82d7b54e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald25f66d794d63b85731f7b7b82d7b54e)): ?>
<?php $component = $__componentOriginald25f66d794d63b85731f7b7b82d7b54e; ?>
<?php unset($__componentOriginald25f66d794d63b85731f7b7b82d7b54e); ?>
<?php endif; ?>
<?php /**PATH C:\Users\TourismoPH\Herd\mmrc_tailoring\resources\views/user/order/customized.blade.php ENDPATH**/ ?>